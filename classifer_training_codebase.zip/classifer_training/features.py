from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from classifer_training.data import ExampleRecord
from classifer_training.utils import coerce_float, get_nested_value, parse_layer_spec, sanitize_name


@dataclass
class FeatureExtractionConfig:
    components: list[str] = field(default_factory=lambda: ["hidden"])
    layers: str | None = "all"
    component_pooling: str = "concat"
    extra_feature_paths: list[str] = field(default_factory=list)
    include_hidden_features: bool = True


def _aggregate_component_vectors(
    component_name: str,
    layer_vectors: list[np.ndarray],
    layer_spec: str | None,
    pooling: str,
) -> tuple[np.ndarray, list[str]]:
    selected_layers = parse_layer_spec(layer_spec, len(layer_vectors))
    selected_vectors = [np.asarray(layer_vectors[layer_idx], dtype=np.float32) for layer_idx in selected_layers]
    if not selected_vectors:
        raise ValueError(f"No layers were selected for component {component_name!r}.")

    reference_dim = selected_vectors[0].shape[0]
    for vector in selected_vectors:
        if vector.ndim != 1 or vector.shape[0] != reference_dim:
            raise ValueError(
                f"All selected vectors for component {component_name!r} must be 1D and share the same dimension."
            )

    if pooling == "concat":
        feature_vector = np.concatenate(selected_vectors, axis=0)
        feature_names = [
            f"{component_name}_layer{layer_idx}_dim{dim_idx}"
            for layer_idx, vector in zip(selected_layers, selected_vectors)
            for dim_idx in range(vector.shape[0])
        ]
        return feature_vector, feature_names

    stacked = np.stack(selected_vectors, axis=0)
    if pooling == "mean":
        pooled = stacked.mean(axis=0)
        suffix = "mean"
    elif pooling == "max":
        pooled = stacked.max(axis=0)
        suffix = "max"
    else:
        raise ValueError(f"Unsupported component pooling mode: {pooling}")

    layer_name = sanitize_name(",".join(str(layer_idx) for layer_idx in selected_layers))
    feature_names = [f"{component_name}_{suffix}_{layer_name}_dim{dim_idx}" for dim_idx in range(pooled.shape[0])]
    return pooled.astype(np.float32), feature_names


def _resolve_numeric_feature(example: ExampleRecord, feature_path: str) -> float:
    search_order: list[tuple[dict[str, Any], str]] = []
    if feature_path.startswith("label."):
        search_order.append((example.label_row, feature_path[len("label.") :]))
    elif feature_path.startswith("index."):
        search_order.append((example.index_row, feature_path[len("index.") :]))
    else:
        search_order.extend(
            [
                (example.label_row, feature_path),
                (example.index_row, feature_path),
            ]
        )

    for source, path in search_order:
        value = get_nested_value(source, path, default=None)
        numeric = coerce_float(value)
        if numeric is not None:
            return numeric
    raise KeyError(
        f"Could not resolve numeric feature {feature_path!r} for task {example.task_id} in dataset {example.dataset_name}."
    )


def build_feature_matrix(
    examples: list[ExampleRecord],
    config: FeatureExtractionConfig,
) -> tuple[np.ndarray, list[str], list[dict[str, Any]]]:
    feature_rows: list[np.ndarray] = []
    feature_names: list[str] | None = None
    metadata_rows: list[dict[str, Any]] = []

    for example in examples:
        parts: list[np.ndarray] = []
        names: list[str] = []

        if config.include_hidden_features:
            for component_name in config.components:
                if component_name not in example.components:
                    raise KeyError(
                        f"Component {component_name!r} is missing for task {example.task_id} in dataset {example.dataset_name}."
                    )
                component_vector, component_names = _aggregate_component_vectors(
                    component_name=component_name,
                    layer_vectors=example.components[component_name],
                    layer_spec=config.layers,
                    pooling=config.component_pooling,
                )
                parts.append(component_vector)
                names.extend(component_names)

        if config.extra_feature_paths:
            extra_values = np.asarray(
                [_resolve_numeric_feature(example, feature_path) for feature_path in config.extra_feature_paths],
                dtype=np.float32,
            )
            parts.append(extra_values)
            names.extend([sanitize_name(feature_path) for feature_path in config.extra_feature_paths])

        if not parts:
            raise ValueError("At least one hidden-state or auxiliary feature must be enabled.")

        row_vector = np.concatenate(parts, axis=0)
        if feature_names is None:
            feature_names = names
        elif feature_names != names:
            raise ValueError("Feature names changed across rows. Hidden-state dimensions are inconsistent.")

        feature_rows.append(row_vector)
        metadata_rows.append(
            {
                "dataset_name": example.dataset_name,
                "task_id": example.task_id,
                "split": example.split,
                "user_input": example.index_row.get("user_input") or example.label_row.get("user_input"),
            }
        )

    return np.stack(feature_rows, axis=0), feature_names or [], metadata_rows
