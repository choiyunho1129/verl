from __future__ import annotations

import argparse
import json
from pathlib import Path

from classifer_training.utils import sanitize_name


def build_manifest(
    model_name: str,
    datasets: list[str],
    hidden_root: Path,
    index_root: Path,
    labels_root: Path,
    hidden_filename: str,
    index_filename: str,
    labels_filename: str,
    default_component_name: str | None,
) -> dict:
    model_slug = sanitize_name(model_name)
    entries = []
    for dataset_name in datasets:
        entry = {
            "name": dataset_name,
            "hidden_states_path": str((hidden_root / dataset_name / model_slug / hidden_filename).resolve()),
            "index_path": str((index_root / dataset_name / model_slug / index_filename).resolve()),
            "labels_path": str((labels_root / dataset_name / model_slug / labels_filename).resolve()),
        }
        if default_component_name:
            entry["default_component_name"] = default_component_name
        entries.append(entry)
    return {"datasets": entries}


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create a manifest for classifer_training using a simple dataset/model "
            "directory convention."
        )
    )
    parser.add_argument("--model_name", required=True)
    parser.add_argument("--datasets", nargs="+", required=True)
    parser.add_argument("--output_path", type=Path, required=True)
    parser.add_argument("--hidden_root", type=Path, required=True)
    parser.add_argument("--index_root", type=Path, required=True)
    parser.add_argument("--labels_root", type=Path, required=True)
    parser.add_argument("--hidden_filename", default="hidden_states.pt")
    parser.add_argument("--index_filename", default="index.jsonl")
    parser.add_argument("--labels_filename", default="sampling_labels.jsonl")
    parser.add_argument("--default_component_name", default=None)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    args = parse_args(argv)
    manifest = build_manifest(
        model_name=args.model_name,
        datasets=args.datasets,
        hidden_root=args.hidden_root.expanduser(),
        index_root=args.index_root.expanduser(),
        labels_root=args.labels_root.expanduser(),
        hidden_filename=args.hidden_filename,
        index_filename=args.index_filename,
        labels_filename=args.labels_filename,
        default_component_name=args.default_component_name,
    )
    output_path = args.output_path.expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Wrote manifest to {output_path}")


if __name__ == "__main__":
    main()
